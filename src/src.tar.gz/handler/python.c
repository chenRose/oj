#include<stdio.h>
#include "common.h"

handler_interface_t *g_handler;
int initial(handler_interface_t *handler,dictionary *handler_ini)
{
	if(handler==NULL)
	{
		printf("error");
	}
	g_handler=handler;
	return 0;
	
}


int compile(const char *task)
{
	const char *compile_cmd [] = {"gcc",task,"-o","main",NULL};
	log_info("我要开始编译了%d\n",getpid());
	execvp(compile_cmd[0],(char * const *)compile_cmd);	
}

int work(const char * task)
{
	char file_path[1024];
	if(task==NULL)
	{
		log_info("[%s:%d]\tworker wating a task...\n",g_handler->name,getpid());
		mymsg_t *msg=malloc(sizeof(mymsg_t));	
		int iRet = msgrcv(g_handler->msg_id,msg,2048,0,0);//block until new command 
		log_info("[%s;%d]get a task，file path is%s\n",g_handler->name,getpid(),msg->task.source);
		strncpy(file_path,msg->task.source,1024);
		free(msg);
	}
	else
	{
		strncpy(file_path,task,1024);
	}
	//1. 先进行编译工作
	
	compile(file_path);	
	
	
	return 0;
}

int reload(handler_interface_t *handler,dictionary* handler_ini)
{
	printf("reload...\n");
	return 0;
}
