#include "common.h"
#include "judger.h"


int handler_get_load(handler_interface_t *handler)
{
	
}
