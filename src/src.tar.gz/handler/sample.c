#include<stdio.h>

void initial()
{
    printf("initial...");
    printf("done");
}

void start()
{
    printf("start...");
}
