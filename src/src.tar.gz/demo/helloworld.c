#include <stdio.h>  
int main(){  
    printf("Hello World!/n");  
	printf("%d.%d\n",getpid(),getppid());
	while(1)
	{
	}
    return 0;  
}  
