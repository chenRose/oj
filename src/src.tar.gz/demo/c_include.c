#include "/home/oj/etc/core_connect.ini"
