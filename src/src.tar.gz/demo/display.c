#include<stdio.h>
#include<stdlib.h>
void main()
{
	printf("hello world\n");
	printf("%d.%d\n",getpid(),getppid());
}
