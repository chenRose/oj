#include </dev/random> 
