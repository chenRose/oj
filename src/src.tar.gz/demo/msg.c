#include<stdio.h>
#include<stdlib.h>
#include<sys/sem.h>
#include<sys/msg.h>
#define SEMPERM 0600

typedef union _semun {
  int val;
  struct semid_ds *buf;
  ushort *array;
} semun;


int main()
{
	int id = msgget(12345,IPC_CREAT);
	printf("first id %d\n",id);
	
	int se_id = msgget(12345,IPC_CREAT|IPC_EXCL);
	printf("secst id is -1= %d\n",se_id);
	
	int id3 = msgget(12345,IPC_CREAT);
	printf("id3 :%d\n",id3);
	msgctl(id3,IPC_RMID,NULL);
	printf("删除。。。");
	int id4 = msgget(12345,IPC_CREAT);
	printf("id4:%d\n",id4);
		
		
	return 0;
}
