#include</dev/zero>

void main()
{
	printf("1");
}
